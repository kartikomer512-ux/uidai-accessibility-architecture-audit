# UIDAI Accessibility Baseline & Repository Architecture Audit

Portfolio project: public-service accessibility audit + accessible full-stack foundation inspired by UIDAI.

## Target

https://uidai.gov.in/

## Deliverables

- Accessibility baseline and five prioritized findings: `docs/audit/accessibility-audit.md`
- Keyboard-only audit checklist: `docs/audit/keyboard-audit.md`
- Structured findings: `docs/audit/findings.csv`
- Architecture boundaries: `docs/architecture/architecture.md`
- Repository tree: `docs/architecture/tree.md`
- Working mock first vertical slice: `client/` + `server/`
- CI test workflow: `.github/workflows/ci.yml`

## First vertical feature

**Aadhaar Service Directory** — a mock catalogue of public service types. It deliberately does not process real Aadhaar numbers, OTPs, biometrics or identity documents.

## Local setup

```bash
npm install
npm run dev
```

Open `http://localhost:5173`.

Run tests:

```bash
npm test
```

## Audit evidence

The audit uses current public UIDAI content, UIDAI's own accessibility documentation, STQC certification information and an independent BuiltWith accessibility signal. Live Lighthouse execution and hands-on keyboard reproduction are identified explicitly where the environment cannot perform them; no score or failure is fabricated.
