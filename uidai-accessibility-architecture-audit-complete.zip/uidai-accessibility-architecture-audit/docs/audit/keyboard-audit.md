# UIDAI keyboard-only audit

**Target:** https://uidai.gov.in/en?i=login

**Method:** After initial page load, test with mouse removed from the workflow: Tab, Shift+Tab, Enter, Space, Escape and arrow keys where applicable.

| Area | Evidence/observation | Priority |
|---|---|---|
| Skip navigation | Current public accessible representation does not expose a skip-link item in the top navigation sequence; an older official UIDAI annual-report screenshot shows a “Main Content” link. Verify current implementation manually. | High |
| Primary navigation | Current page exposes Home, My Aadhaar, About UIDAI, Build with Us, Media, Documents and Help. Verify focus order and menu expansion/collapse. | High |
| Language controls | Entry page exposes 13 language buttons. Verify all are reachable, visibly focused and operable. | High |
| Carousel/banner | Multiple homepage slides are present. Verify pause/next/previous behavior and focus interaction. | High |
| Footer regional-office input | Accessible extraction exposes an unlabeled-looking `[Input]`. Verify actual accessible name. | High |

This audit deliberately distinguishes web-observable evidence from hands-on keyboard verification. Do not claim a keyboard failure until it has been reproduced locally.
