# Screenshots

Add live Lighthouse and keyboard screenshots here after running the target site locally. Suggested files:

- `lighthouse-home.png`
- `keyboard-navigation.png`
- `language-selection-focus.png`
- `regional-office-input.png`
- `carousel-controls.png`
- `contrast-evidence.png`

The repository does not fabricate screenshots of the live site.
