# UIDAI Accessibility Baseline & Architecture Audit

**Target:** Unique Identification Authority of India (UIDAI)

**Primary URL:** https://uidai.gov.in/

**Audit date:** 29 August 2026

## Executive summary

UIDAI states that its website is intended to be accessible regardless of device, technology or ability and says it follows WCAG 2.0 Level AA and Guidelines for Indian Government Websites. The site is also listed by STQC as certified under Guidelines for Indian Government Websites (GIGW) v2.0, certification GIGW/2023/Q1/72, valid through 4 October 2026.

The audit therefore focuses on residual risk and maintainability rather than assuming the site's conformance claim is false.

## Evidence sources

1. UIDAI homepage and accessible content representation.
2. UIDAI Website Help / Screen Reader documentation.
3. UIDAI language-selection entry page.
4. UIDAI Style Guide.
5. BuiltWith external performance/accessibility profile for color contrast.
6. STQC certified website list.

## Lighthouse

A live Lighthouse run could not be executed in this environment because the browser sandbox cannot reach the public site directly. The report therefore does **not** fabricate a Lighthouse score. Run Lighthouse locally and append the screenshot and score to this section before final submission.

## Five prioritized findings

### UIDAI-001 — Regional-office input has no clear accessible name in extracted representation

**WCAG:** 1.3.1 / 3.3.2

The current homepage's accessible content representation contains an `[Input]` immediately before the “UIDAI Regional Office, Guwahati” content, without a label exposed in the extracted representation. This is sufficient to flag the control for inspection; final confirmation should be made against the live DOM.

**Priority: High.**

**Remediation:** add an explicit visible label and ensure the input's accessible name describes the task.

### UIDAI-002 — Generic image names require an alternative-text audit

**WCAG:** 1.1.1

The current page representation includes generic image labels such as “Image”, “Image: Arrow”, “Image: Decorative background”, while meaningful assets such as the UIDAI logo, QR code and service imagery are also present. Generic alternative text is a quality risk because it can create low-value announcements for assistive-technology users.

**Priority: Medium.**

**Remediation:** informative images need concise purpose-based alt text; decorative images should use empty alt text.

### UIDAI-003 — Homepage carousel needs pause/keyboard verification

**WCAG:** 2.2.2 / 2.1.1

The homepage currently exposes a sequence of banner slides. The accessible page representation lists multiple slide images/headings but no pause control. This is a manual verification target for auto-rotation, keyboard operation and focus behavior.

**Priority: High if auto-rotation is confirmed.**

**Remediation:** provide pause/stop controls, keyboard-operable previous/next controls and stop rotation on interaction.

### UIDAI-004 — Color contrast issue reported by external scanner

**WCAG:** 1.4.3

BuiltWith's current UIDAI performance profile explicitly reports “Color Contrast” as an issue that may affect accessibility. This is independent evidence and should be reproduced with Lighthouse/axe or a contrast analyzer before using an exact selector in the final report.

**Priority: High.**

**Remediation:** identify failing foreground/background pairs and adjust them to meet WCAG contrast requirements.

### UIDAI-005 — Multilingual entry is a critical keyboard/accessibility checkpoint

**WCAG:** 2.1.1 / 2.4.4 / 3.2.1

UIDAI's entry page presents 13 language choices as buttons. Because this screen is the gateway to the service, any keyboard, focus, accessible-name or context-preservation problem has unusually high user impact.

**Priority: High if reproduced.**

**Remediation:** unique accessible names, visible focus, logical tab order, predictable activation and preserved language/context.

## Remediation priority

| Priority | Finding | Reason |
|---|---|---|
| 1 | UIDAI-001 | Potentially blocks identification of a functional input |
| 2 | UIDAI-003 | Moving content can affect keyboard and cognitive access |
| 3 | UIDAI-004 | Direct readability impact for low-vision users |
| 4 | UIDAI-005 | Gateway control affects the whole multilingual experience |
| 5 | UIDAI-002 | Important but generally less task-blocking |

## Architecture observations

The current site has a broad service catalogue, multilingual entry, dynamic promotional content, service links into MyAadhaar, documents, dashboards, videos and external systems. The maintainable prototype in this repository therefore separates presentation, API, service logic and data boundaries.

## Limitations

This is a targeted baseline, not a full WCAG conformance assessment. Some findings are web-observable risk indicators and require live DOM/keyboard verification. No real Aadhaar identity information is used.
