# Architecture

## Scope

This is an inferred architecture for an accessible public-service prototype. It is not UIDAI's private production architecture.

```mermaid
flowchart TD
 Browser --> Client
 Client -->|HTTPS| API
 API --> Controller
 Controller --> Service
 Service --> Repository
```

## Boundaries

- **Client:** semantic UI, routing, focus/keyboard behavior, accessibility state, API client.
- **Server:** HTTP routes, validation, business rules, integration boundaries.
- **Repository:** data source boundary; this prototype uses safe in-memory mock data.

## First vertical slice

Aadhaar Service Directory: search/filter service catalogue -> `GET /api/services` -> controller/API boundary -> mock service directory -> accessible result cards.

## Security boundary

No Aadhaar number, OTP, biometric data, identity document, or authentication secret is accepted by this prototype.

## Accessibility architecture

Semantic HTML first; visible `:focus-visible`; skip link; explicit labels; logical headings; keyboard-operable controls; `aria-live` for result status; automated axe/Playwright checks in the intended next CI stage.
