# Repository tree

```text
uidai-accessibility-architecture-audit/
├── client/
├── server/
├── docs/
│   ├── audit/
│   └── architecture/
├── tests/
│   ├── accessibility/
│   └── e2e/
├── .github/workflows/ci.yml
├── package.json
└── README.md
```
