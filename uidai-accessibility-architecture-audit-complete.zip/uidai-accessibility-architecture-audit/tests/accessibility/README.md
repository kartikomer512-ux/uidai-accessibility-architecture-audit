# Accessibility regression test plan

Recommended next CI step: install Playwright and axe-core, start the app, then assert zero serious/critical axe violations. Also verify the skip link, visible focus, labelled search field, logical heading order, and the live search result status.
