# E2E test plan

1. Open `/`.
2. Press Tab and verify the skip link is first.
3. Activate it and verify focus reaches `#main-content`.
4. Search for `status`.
5. Verify `Check Update Status` remains visible.
6. Verify the live region reports the result count.
